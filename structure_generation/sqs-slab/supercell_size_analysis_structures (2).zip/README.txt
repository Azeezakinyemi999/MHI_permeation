Supercell Size Analysis - Structure Files
============================================================

Directory Structure:

supercell_1x1x1/
  - 10 structures
  - 360 atoms per structure
  - Mean score: 0.4969

supercell_2x2x2/
  - 10 structures
  - 2880 atoms per structure
  - Mean score: 0.8154

supercell_3x3x3/
  - 10 structures
  - 9720 atoms per structure
  - Mean score: 0.9083


File Naming Convention:
POSCAR_XXX_score_Y.YYYY.vasp
  - XXX: Sample ID (001, 002, ...)
  - Y.YYYY: Randomness score

Total Files: 30
